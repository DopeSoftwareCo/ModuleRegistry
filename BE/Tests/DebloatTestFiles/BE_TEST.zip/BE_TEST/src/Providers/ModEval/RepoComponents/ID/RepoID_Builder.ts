import { RepoURL } from "../URL/URLProcessor.interface";
import { URLProcessor } from "../URL/URLProcessor";
import { AsyncBuilder } from "../../../../Classes/Abstract/Abstract_Builders";
import { IsType_RepoURL } from "../../../../DSinc_Modules/CustomTypeGuards/ModEval_Guards";
import { AsyncLoops } from "../../../../DSinc_Modules/DSinc_LoopsMaps";
import { RepoID } from "./RepoID";

export class RepoID_Builder extends AsyncBuilder<RepoID> {
    constructor(trackCreations: boolean = false) {
        super(trackCreations);
    }

    async MultiBuild(repoURLs: Array<RepoURL>): Promise<Array<RepoID> | undefined> {
        if (repoURLs.length < 1) {
            return undefined;
        }

        let creations = Array<RepoID>();
        await AsyncLoops.DiscardUndefined_StoreForEach<RepoURL, RepoID>(
            repoURLs,
            creations,
            this.Build.bind(this),
            false
        );
        return creations;
    }

    async Build(rawURL: string): Promise<RepoID | undefined>;
    async Build(repoURL: RepoURL): Promise<RepoID | undefined>;

    async Build(source: any): Promise<RepoID | undefined> {
        let creation: RepoID | undefined;

        if (!source) {
            return undefined;
        }

        if (typeof source === "string") {
            creation = await this.StartFrom_String(source);
        } else if (IsType_RepoURL(source)) {
            creation = await this.StartFrom_RepoURL(source);
        } else {
            creation = undefined;
        }
        return creation;
    }

    private async StartFrom_String(rawURL: string): Promise<RepoID | undefined> {
        const processor = new URLProcessor();

        const repoURL: RepoURL | undefined = await processor.Process(rawURL);

        if (repoURL) {
            return await this.StartFrom_RepoURL(repoURL);
        }
        return undefined;
    }

    private async StartFrom_RepoURL(repoURL: RepoURL): Promise<RepoID | undefined> {
        try {
            if (!repoURL) {
                return undefined;
            }
            let nameofOwner = "";
            let nameofRepo = "";

            if (repoURL.tokens.IsDefined) {
                const content = repoURL.tokens.Content;
                nameofOwner = content[1];
                nameofRepo = content[2];
            }

            const creation = new RepoID(nameofOwner, nameofRepo, repoURL);
            return creation;
        } catch {
            return undefined;
        }
    }
}
