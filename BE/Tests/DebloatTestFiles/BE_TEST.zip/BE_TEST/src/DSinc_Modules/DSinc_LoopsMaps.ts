export function TryIndexOrDefaultTo<T>(arr: Array<T>, index: number, defaultTo: T): T {
    if (index >= 0 && index < arr.length) {
        return arr[index] !== undefined ? arr[index] : defaultTo;
    }
    return defaultTo;
}

export namespace AsyncLoops {
    export async function ForEach<MethodParam, MethodReturn>(
        items: MethodParam[],
        method: (item: MethodParam) => Promise<MethodReturn>,
        runSequential: boolean = false
    ): Promise<void> {
        if (runSequential) {
            for (let item of items) {
                // 'let' allows modification of 'item'
                // This await means qait for each promise to resolve before continuing
                await method(item);
            }
        } else {
            const promises = items.map(method);
            await Promise.all(promises);
        }
    }

    export async function StoreForEach<MethodParam, TypeToStore>(
        items: MethodParam[],
        storage: Array<TypeToStore>,
        method: (item: MethodParam) => Promise<TypeToStore>,
        runSequential: boolean = false
    ): Promise<void> {
        if (runSequential) {
            for (let item of items) {
                let result = await method(item); // Wait for each promise to resolve before continuing
                storage.push(result);
            }
        } else {
            const promises = items.map(method);
            storage = await Promise.all(promises);
        }
    }

    // The idea to address foreach not supporting async in this way came from Google Gemini
    export async function DiscardUndefined_StoreForEach<MethodParam, TypeToStore>(
        items: MethodParam[],
        storage: Array<TypeToStore>,
        method:
            | ((item: MethodParam) => Promise<TypeToStore>)
            | ((item: MethodParam) => Promise<TypeToStore | undefined>),
        runSequential: boolean = false
    ): Promise<void> {
        if (runSequential) {
            for (let item of items) {
                // 'let' allows modification of 'item'
                let result = await method(item); // Wait for each promise to resolve before continuing
                if (result) {
                    storage.push(result);
                }
            }
        } else {
            const promises = items.map(method);
            const results = await Promise.all(promises);

            results.forEach((element) => {
                if (element) {
                    storage.push(element);
                }
            });
        }
    }
}
